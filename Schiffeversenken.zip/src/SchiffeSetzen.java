import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Array;
import java.text.DecimalFormat;
import java.util.ArrayList;

import javax.swing.AbstractAction;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.LineBorder;

public class SchiffeSetzen extends JFrame implements ActionListener
{
	JButton LastClicked=null;
	JButton Setzer=null;

	int bclicked=0;
	int maxS=0;
	int Spieler;
	boolean binit=true;

	String ButtonName1;
	String ButtonName2;
	String xCoord1;
	String yCoord1;
	String xCoord2;
	String yCoord2;



	public SchiffeSetzen(int a)
	{
		int b;
		int c;
		String bs;
		String cs;
		this.Spieler=a;

		JPanel panel=new JPanel(new BorderLayout());

		this.setTitle("Spieler "+Spieler+" Schiffe setzen");
		this.setPreferredSize(new Dimension(700, 700));
		panel.setBackground(Color.WHITE);
		this.pack();

		panel.setLayout(new GridLayout(10,10,1,1));
		for(int i = 0; i < 100; i++){
			c=(i+1)%10;
			if(c==0)
			{
				c=10;
			}
			b=(i/10)+1;

			DecimalFormat format = new DecimalFormat("00");
			bs=format.format(new Double(String.valueOf(b)));
			cs=format.format(new Double(String.valueOf(c)));

			JButton button = new JButton(c+"|"+b);
			button.setActionCommand(cs+"|"+bs);
			button.addActionListener(this);
			button.setBackground(Color.BLUE);

			try{
				UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
			}catch(Exception e){
				e.printStackTrace();
			}

			panel.add(button);
		}
		this.add(panel,BorderLayout.CENTER);
		ZusatzButtons();
		init();
	}

	private void init()
	{
		this.pack();	
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}

	private void ZusatzButtons()
	{
		JButton drehbutton = new JButton(new AbstractAction("drehen"){
			@Override
			public void actionPerformed(ActionEvent e)
			{

			}
		});

		JButton setzer = new JButton(new AbstractAction("setzen"){
			@Override
			public void actionPerformed(ActionEvent e)
			{
				if(Spieler==1)
				{
					ButtonName1=LastClicked.getActionCommand();
					//System.out.println(ButtonName1);
					xCoord1=ButtonName1.substring(0,2);
					yCoord1=ButtonName1.substring(3,5);
					//System.out.println(xCoord1+"+"+yCoord1);
					Game.schiffeSpieler1.add(new Punkt (Integer.parseInt(xCoord1),Integer.parseInt(yCoord1)));
					LastClicked.setEnabled( false );
				}

				if(Spieler==2)
				{
					ButtonName2=LastClicked.getActionCommand();
					//System.out.println(ButtonName2);
					xCoord2=ButtonName2.substring(0,2);
					yCoord2=ButtonName2.substring(3,5);
					//System.out.println(xCoord2+"+"+yCoord2);
					Game.schiffeSpieler2.add(new Punkt (Integer.parseInt(xCoord2),Integer.parseInt(yCoord2)));
					LastClicked.setEnabled( false );
				}

				LastClicked=null;
				bclicked=0;
				maxS++;
				Setzer.setEnabled(false);
				
				if(Game.schiffeSpieler1.size()+Game.schiffeSpieler2.size()==14)
				{
					Game.arrayAusgeben();
					Game.status="spielen";
					Game.zeichneSpielbrett();
				}
				
				if(Game.schiffeSpieler1.size()==7)
				{
					Game.disposeWindow(1);
				}
				
				if(Game.schiffeSpieler2.size()==7)
				{
					Game.disposeWindow(2);
				}
			}
		});
		JButton umsetzen = new JButton(new AbstractAction("umsetzen"){
			@Override
			public void actionPerformed(ActionEvent e)
			{
				LastClicked.setBackground(Color.BLUE);
				bclicked=0;
			}
		});
		JPanel panel2=new JPanel();
		//panel2.add(umsetzen);
		//panel2.add(drehbutton);
		panel2.add(setzer);
		Setzer=setzer;
		Setzer.setEnabled(false);
		this.add(panel2,BorderLayout.PAGE_END);
		if(binit==true)
		{
			init();
			binit=false;
		}

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(maxS<=6)
		{
			((JButton) e.getSource()).setBackground(Color.RED);
			//ZusatzButtons();
			Setzer.setEnabled(true);
			if(e.getSource().equals(LastClicked)&&LastClicked.getBackground()==Color.BLUE)
			{
				bclicked=0;
				LastClicked=null;
			}		
			else if(bclicked==1)
			{
				LastClicked.setBackground(Color.BLUE);
			}
			else
			{
				bclicked=1;
			}
			LastClicked=(JButton)e.getSource();
		}
	}

	public JButton getLastClick()
	{
		return LastClicked;
	}
}

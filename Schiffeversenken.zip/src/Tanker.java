
public class Tanker extends Schiff{
		
	public Tanker(Punkt p, Richtung.Orientierung o)
	{
		super(p,o);
		this.laenge = 4;
	}

}

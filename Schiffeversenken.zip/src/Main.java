import javax.swing.JFrame;

public class Main {

	public static void main(String[] args) {
		
		/*
		Schiff s=new Tanker( new Punkt (1,1) , Richtung.Orientierung.N);
		System.out.println("Ich bin ein Tanker, bin " + s.getLaenge() +" lang und bin auf der Position "+ s.getX() +" | "+ s.getY()+" | "+s.getOrientierung());
		Schiff s1=new Tanker( new Punkt (2,2) , Richtung.Orientierung.N);
		System.out.println("Ich bin ein Tanker, bin " + s1.getLaenge() +" lang und bin auf der Position "+ s1.getX() +" | "+ s1.getY()+" | "+s1.getOrientierung());
		Schiff s2=new UBoot( new Punkt (3,3) , Richtung.Orientierung.N);
		System.out.println("Ich bin ein UBoot, bin " + s2.getLaenge() +" lang und bin auf der Position "+ s2.getX() +" | "+ s.getY()+" | "+s.getOrientierung());
		Schiff s3=new UBoot( new Punkt (4,4) , Richtung.Orientierung.N);
		System.out.println("Ich bin ein UBoot, bin " + s3.getLaenge() +" lang und bin auf der Position "+ s3.getX() +" | "+ s3.getY()+" | "+s3.getOrientierung());
		Schiff s4=new Speedboot( new Punkt (5,5) , Richtung.Orientierung.N);
		System.out.println("Ich bin ein Speedboot, bin " + s4.getLaenge() +" lang und bin auf der Position "+ s4.getX() +" | "+ s4.getY()+" | "+s4.getOrientierung());
		Schiff s5=new Speedboot( new Punkt (6,6) , Richtung.Orientierung.N);
		System.out.println("Ich bin ein Speedboot, bin " + s5.getLaenge() +" lang und bin auf der Position "+ s5.getX() +" | "+ s5.getY()+" | "+s5.getOrientierung());
		
		JFrame schiffesetzenS1 = new SchiffeSetzen(1);

		JFrame schiffesetzenS2 = new SchiffeSetzen(2);

		JFrame schießenS1 = new SchiffeAbschießen(1);

		JFrame schießenS2 = new SchiffeAbschießen(2);
		*/
		Game game=new Game(0, 0, 0, 0, 0);
		//game.platziereSchiff(s.getX(),s.getY(),s.getOrientierung(), s.getLaenge());
		game.zeichneSpielbrett();
		
		
	}

}

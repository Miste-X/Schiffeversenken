import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;

import javax.swing.AbstractAction;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.LineBorder;

public class SchiffeAbschiessen extends JFrame implements ActionListener
{
	JButton Fire=null;
	JButton LastClicked=null;
	
	int bclicked=0;
	int Spieler;

	String ButtonName1;
	String ButtonName2;
	String xCoord1;
	String yCoord1;
	String xCoord2;
	String yCoord2;

	Color light_blue = new Color(51,153,255);

	public SchiffeAbschiessen(int a)
	{
		this.Spieler=a;

		int b;
		int c;
		String bs;
		String cs;
		JPanel panel=new JPanel(new BorderLayout());

		this.setTitle("Spieler "+Spieler+" Schiffe abschiessen");
		this.setPreferredSize(new Dimension(650, 650));
		this.setBackground(Color.WHITE);
		this.pack();

		panel.setLayout(new GridLayout(10,10,1,1));
		for(int i = 0; i < 100; i++){
			c=(i+1)%10;
			if(c==0)
			{
				c=10;
			}
			b=(i/10)+1;

			DecimalFormat format = new DecimalFormat("00");
			bs=format.format(new Double(String.valueOf(b)));
			cs=format.format(new Double(String.valueOf(c)));

			JButton button = new JButton(c+"|"+b);
			button.setActionCommand(cs+"|"+bs);
			button.addActionListener(this);
			button.setBackground(light_blue);

			try{
				UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
			}catch(Exception e){
				e.printStackTrace();
			}

			panel.add(button);
		}
		this.add(panel,BorderLayout.CENTER);
		ZusatzElemente();
		init();
	}

	private void ZusatzElemente()
	{
		JPanel panel2=new JPanel();
		JButton fire=new JButton(new AbstractAction("FIRE!"){
			@Override
			public void actionPerformed(ActionEvent e)
			{
				if(Spieler==1)
				{
					ButtonName1=LastClicked.getActionCommand();
					xCoord1=ButtonName1.substring(0,2);
					yCoord1=ButtonName1.substring(3,5);
					Punkt p=new Punkt (Integer.parseInt(xCoord1),Integer.parseInt(yCoord1));
					Game.schuesseGefeuertSpieler1.add(p);
					LastClicked.setEnabled( false );
					if(Game.Schuss(p,1))
					{
						LastClicked.setBackground(Color.RED);
					}
					else
					{
						LastClicked.setBackground(Color.BLUE);
					}
				}

				if(Spieler==2)
				{
					ButtonName2=LastClicked.getActionCommand();
					xCoord2=ButtonName2.substring(0,2);
					yCoord2=ButtonName2.substring(3,5);
					Punkt p=new Punkt (Integer.parseInt(xCoord2),Integer.parseInt(yCoord2));
					Game.schuesseGefeuertSpieler2.add(p);
					LastClicked.setEnabled( false );
					if(Game.Schuss(p,2))
					{
						LastClicked.setBackground(Color.RED);
					}
					else
					{
						LastClicked.setBackground(Color.BLUE);
					}	
				}

				LastClicked=null;
				bclicked=0;
				Fire.setEnabled(false);

				if(Game.schiffeSpieler1.size()==0)
				{
					System.out.println("Spieler 2 hat gewonnen!");
					Game.status="beendet";
					Game.zeichneSpielbrett();
				}

				if(Game.schiffeSpieler2.size()==0)
				{
					System.out.println("Spieler 1 hat gewonnen!");
					Game.status="beendet";
					Game.zeichneSpielbrett();
				}




			}
		});
		JTextField info=new JTextField();
		info.setEditable(false);
		panel2.add(fire);
		//panel2.add(info);
		Fire=fire;
		Fire.setEnabled(false);
		this.add(panel2,BorderLayout.PAGE_END);
		//info.setText("Schiffe abschiessen!");
	}

	private void init()
	{
		this.pack();	
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}


	@Override
	public void actionPerformed(ActionEvent e) {

		((JButton) e.getSource()).setBackground(Color.ORANGE);
		Fire.setEnabled(true);
		if(e.getSource().equals(LastClicked)&&LastClicked.getBackground()==light_blue)
		{
			bclicked=0;
			LastClicked=null;
		}		
		else if(bclicked==1)
		{
			LastClicked.setBackground(light_blue);
		}
		else
		{
			bclicked=1;
		}
		LastClicked=(JButton)e.getSource();
	}


	public JButton getLastClick()
	{
		return LastClicked;
	}
}

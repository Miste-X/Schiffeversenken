import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.*;

import java.awt.Graphics;
import java.awt.Image;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.lang.reflect.Array;

public class Game /*throws IOException*/{

	static JFrame schiffesetzenS1;
	static JFrame schiffesetzenS2;
	static JFrame schie�enS1;
	static JFrame schie�enS2;


	private int nrTanker;
	private int nrUBoot;
	private int nrSpeedboot;
	private int sizeX;
	private int sizeY;

	private static boolean removed=false;

	static ArrayList <Punkt> schiffeSpieler1=new ArrayList<Punkt>();
	static ArrayList <Punkt> schiffeSpieler2=new ArrayList<Punkt>();
	static ArrayList <Punkt> schuesseGefeuertSpieler1=new ArrayList<Punkt>();
	static ArrayList <Punkt> schuesseGefeuertSpieler2=new ArrayList<Punkt>();

	static String status="setzen";

	public Game(int nrT, int nrU, int nrS, int sizeX, int sizeY)
	{
		this.nrTanker=nrT;
		this.nrUBoot=nrU;
		this.nrSpeedboot=nrS;
		this.sizeX=sizeX;
		this.sizeY=sizeY;

	}

	public void platziereSchiff(int x, int y, Richtung.Orientierung o, int laenge)
	{

	}


	public static void zeichneSpielbrett()
	{
		if(status=="setzen")
		{
			schie�enS1=new SchiffeAbschiessen(0);
			schie�enS1.dispose(); //verhindert Grafikbug

			schiffesetzenS1 = new SchiffeSetzen(1);
			schiffesetzenS1.setResizable(false);
			schiffesetzenS2 = new SchiffeSetzen(2);
			schiffesetzenS2.setResizable(false);

		}

		if(status=="spielen")
		{
			schiffesetzenS1.dispose();
			schiffesetzenS2.dispose();
			schie�enS1 = new SchiffeAbschiessen(1);
			schie�enS1.setResizable(false);
			schie�enS2 = new SchiffeAbschiessen(2);
			schie�enS2.setResizable(false);
		}

		if(status=="beendet")
		{
			schie�enS1.dispose();
			schie�enS2.dispose();
		}


	}

	public static boolean Schuss(Punkt p, int Spielernummer)
	{
		if(Spielernummer==1)
		{
			for(int i=0; i<schiffeSpieler2.size();i++)
			{
				if(p.equals(schiffeSpieler2.get(i)))
				{
					schiffeSpieler2.remove(i);
					return true;
				}
			}
		}
		if(Spielernummer==2)
		{
			for(int i=0; i<schiffeSpieler1.size();i++)
			{
				if(p.equals(schiffeSpieler1.get(i)))
				{
					schiffeSpieler1.remove(i);
					return true;
				}
			}
		}
		return false;
	}

	public void aktuellenStatusAuswerten()
	{
		switch(status){
		case "setzen":
			break;
		case "spielen":
			break;
		case "beendet":
			break;
		}
	}

	public static void arrayAusgeben()
	{
		if(schiffeSpieler1.size()+schiffeSpieler2.size()==14)
		{
			System.out.println("Schiffe Spieler 1:");
			for(Punkt p : schiffeSpieler1){
				System.out.println(p.getX()+"/"+p.getY());
			}
			System.out.println("Schiffe Spieler 2:");
			for(Punkt a : schiffeSpieler2){
				System.out.println(a.getX()+"/"+a.getY());
			}
		}

	}

	public static void disposeWindow(int s)
	{
		if(s==1)
		{
			schiffesetzenS1.dispose();
		}
		if(s==2)
		{
			schiffesetzenS2.dispose();
		}
	}

}	



public class UBoot  extends Schiff{
	
	public UBoot(Punkt p, Richtung.Orientierung o)
	{
		super(p,o);
		this.laenge = 3;
	}

}

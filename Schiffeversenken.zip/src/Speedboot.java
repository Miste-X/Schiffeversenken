
public class Speedboot  extends Schiff{

	public Speedboot(Punkt p, Richtung.Orientierung o)
	{
		super(p,o);
		this.laenge = 2;
	}
}

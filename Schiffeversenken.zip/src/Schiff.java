
public class Schiff {
	protected int laenge;
	protected Punkt ursprung;
	protected Richtung.Orientierung orientierung;
	protected int x;
	protected int y;
	
	public Schiff(Punkt p, Richtung.Orientierung o)
	{
		this.ursprung=p;
		this.x=ursprung.getX();
		this.y=ursprung.getY();
		this.setOrientierung(o);
		//System.out.println(p.getX() +" | "+ p.getY());
		//System.out.println(ursprung.getX() +" | "+ ursprung.getY());
		
		
	}
	
	/*
	public Schiff(int x, int y)
	{
		Punkt p=new Punkt(x,y);
		this.ursprung =p;
		
	}
	*/
	
	public void setUrsprung(Punkt p)
	{
		this.ursprung=p;
	}
	
	public void setOrientierung(Richtung.Orientierung o)
	{
		this.orientierung=o;
	}
	
	public Richtung.Orientierung getOrientierung()
	{
		return this.orientierung;
	}
	
	public int getLaenge()
	{
		return this.laenge;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}

}


public class Richtung {

	public static enum Orientierung {
		N,
		O
	}
	
}
